_______________________________________________________________________
WinKey Killer - Version 1.7
Freeware
Copyright (c) 2000 Brad Jackson
E-Mail: bjackson@plutonium.net
Web site: http://home.plutonium.net/~bjackson
(Check here for the latest version)
_______________________________________________________________________

Purpose:
To disable the Windows key and context menu key on newer 104-key Windows
95 keyboards.  Optionally disable all system keys for security purposes.

Why you need it:
If you've ever been in a full screen DOS program or DirectX game in
Windows 95 and accidentally hit the Windows key down by the spacebar, you
know how annoying it is to unexpectedly get jumped back to the Windows
taskbar to watch the Start menu pop up.  Microsoft, in their infinite
wisdom, didn't give users a way to disable these keys.  Now you have an
easy way to fix this "feature" of Windows.  I have WinKey Killer running
on my machine all the time since I rarely use the keys.  I am totally
"rodent dependent" and use the mouse to open the Start menu or a popup
menu.

Installing and running WinKey Killer:
Just copy all the files into a directory.  (Sorry, I didn't have a
choice about a yucky separate DLL file.  That's what Windows needs for
it to work properly.)  Run the program manually or create a shortcut to
the program in your Startup group if you want the program to run
automatically upon starting Windows.  There's no visible window, so
WinKey Killer will quietly launch, disable the keys you have set to
disable and go to sleep.  To shut down the program, run it a second time
and it will close itself.  You can also press Ctrl+Alt+Del and press
End Task and it will close itself.  This program is free for use at
work or home.

Configuration:
Run WKKSetup.exe to set the disabling options.  You can also change the
options manually in the WKeyKill.ini file.  Double click the file to open
it in Notepad or your favorite text editor.  Details about setting the
options are provided in the file.  The defaults should be fine for most
people, but feel free to play with the settings.  It is recommended that
you close WinKey Killer before changing any options.  Note that you must
press OK in the Setup window or save your changes to WKeyKill.ini and then
close and restart WinKey Killer for the changes to take effect.  

About the design:
The program was designed to use as little memory, disk space and
processor time as is practically possible.  It should have virtually
no impact on performance with even the slowest 486 or Pentium computers.
The program uses 9.5KB of disk space and 40KB of memory.  Other programs
available on the Web that also disable the Windows key use hundreds of
kilobytes of disk space and 1-3 megabytes of memory.  Some even use
enormous, bloated runtime libraries that you have to download if you
don't all ready have them.  And on top of that, they want money for their
utility.  Spending money and wasting megabytes of memory on a utility
that has a very simple purpose such as this is just not acceptable.
Lean and mean is the way to go.

Revision history:
1.7 - Minor fixes and streamlining.  By request, added command line
      parameter /s to force program to close even if ShutDownWhenRunAgain=0.
1.6 - Graphical interface to configure program settings.
1.5 - Added option to disable the program setting itself to idle.
      Disable this option if you have sluggish keyboard response in a DOS
      application running on Windows NT.
1.4 - Internal improvements to make program faster and smaller.  I didn't
      think it could be done, but I proved myself wrong.
1.3 - Fixed so disables properly on NT 4.  This also fixed an intermittent
      problem with Windows key being enabled after pressing <Alt> and
      <Esc> keys.
1.2 - By request, added option to prevent WinKey Killer from shutting down
      if you run it a second time
1.1 - Added option to disable all the WinKey combinations like WinKey+E
      for Explorer and WinKey+F for Find
1.0 - First release

Suggestions:
If you have any suggestions as far as improving the program or if you
have any problems (or bug reports), send me an e-mail at
bjackson@plutonium.net or visit my Web site at
http://home.plutonium.net/~bjackson
